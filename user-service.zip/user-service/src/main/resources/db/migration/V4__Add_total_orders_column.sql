ALTER TABLE users ADD COLUMN total_orders BIGINT;
