CREATE TABLE logs(
    id BIGSERIAL PRIMARY KEY,
    description VARCHAR(255) NOT NULL
);

COMMENT ON TABLE logs IS 'Table for logs';