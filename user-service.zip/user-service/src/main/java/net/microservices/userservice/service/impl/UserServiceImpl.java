package net.microservices.userservice.service.impl;

import net.microservices.basedomains.event.FailedApproveOrderEvent;
import net.microservices.basedomains.event.OrderApprovedEvent;
import net.microservices.basedomains.event.OrderCreatedEvent;
import net.microservices.basedomains.event.OrderRejectedEvent;
import net.microservices.userservice.exception.ResourceNotFoundException;
import net.microservices.userservice.dto.UserRequest;
import net.microservices.userservice.dto.UserResponse;
import net.microservices.userservice.entity.User;
import net.microservices.userservice.exception.EmailAlreadyExistException;
import net.microservices.userservice.repository.UserRepository;
import net.microservices.userservice.service.UserService;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.RetryableTopic;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.retrytopic.TopicSuffixingStrategy;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.retry.annotation.Backoff;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {

    @Value("${spring.kafka.order_approved.name}")
    private String orderApprovedTopic;

    @Value("${spring.kafka.order_rejected.name}")
    private String orderRejectedTopic;

    private static final Logger LOGGER = LoggerFactory.getLogger(UserServiceImpl.class);

    private final UserRepository userRepository;

    private final ModelMapper modelMapper;

    private final KafkaTemplate<String, Object> kafkaTemplate;

    public UserServiceImpl(UserRepository userRepository, ModelMapper modelMapper, KafkaTemplate<String, Object> kafkaTemplate) {
        this.userRepository = userRepository;
        this.modelMapper = modelMapper;
        this.kafkaTemplate = kafkaTemplate;
    }

    @Override
    public UserResponse createUser(UserRequest userRequest) {
        LOGGER.atInfo().log(String.format("%s -> received user request", getClass().getSimpleName()));

        Optional<User> optionalUser = userRepository.findByEmail(userRequest.getEmail());

        if (optionalUser.isPresent()) {
            throw new EmailAlreadyExistException("Email already exist for User");
        }

        User user = modelMapper.map(userRequest, User.class);
        LOGGER.atInfo().log(String.format("%s -> User created", getClass().getSimpleName()));

        User savedUser = userRepository.save(user);
        LOGGER.atInfo().log(String.format("%s -> User was saved in the database", getClass().getSimpleName()));

        UserResponse userResponse = modelMapper.map(savedUser, UserResponse.class);
        LOGGER.atInfo().log(String.format("%s -> send response to the controller", getClass().getSimpleName()));

        return userResponse;
    }

    @Override
    public UserResponse getUserById(Long userId) {
        LOGGER.atInfo().log(String.format("%s -> received user id", getClass().getSimpleName()));

        User user = userRepository.findById(userId).orElseThrow(
                () -> new ResourceNotFoundException("User", "id", userId)
        );

        UserResponse userResponse = modelMapper.map(user, UserResponse.class);
        LOGGER.atInfo().log(String.format("%s -> send user to the controller", getClass().getSimpleName()));

        return userResponse;
    }

    @KafkaListener(topics = "${spring.kafka.order_created.name}", groupId = "${spring.kafka.consumer.group-id}")
    @RetryableTopic(
            attempts = "3",
            backoff = @Backoff(delay = 1000, multiplier = 2.0),
            autoCreateTopics = "true",
            topicSuffixingStrategy = TopicSuffixingStrategy.SUFFIX_WITH_INDEX_VALUE,
            dltTopicSuffix = "-dlt",
            include = {ResourceNotFoundException.class, Exception.class}
    )
    public void consumeOrderCreatedEvent(OrderCreatedEvent orderCreatedEvent) {
        LOGGER.atInfo().log(String.format("%s -> received order created event", getClass().getSimpleName()));

        User user = userRepository.findById(orderCreatedEvent.getUserId()).orElseThrow(
                () -> new ResourceNotFoundException("User", "id", orderCreatedEvent.getUserId())
        );

        if (user.getBalance() >= orderCreatedEvent.getTotalPrice()) {
            LOGGER.atInfo().log(String.format("%s -> balance >= total price", getClass().getSimpleName()));

            user.setBalance(user.getBalance() - orderCreatedEvent.getTotalPrice());
            user.setTotalOrders(user.getTotalOrders() + 1);
            userRepository.save(user);
            LOGGER.atInfo().log(String.format("%s -> User updated", getClass().getSimpleName()));

            OrderApprovedEvent orderApprovedEvent = new OrderApprovedEvent();
            orderApprovedEvent.setOrderId(orderCreatedEvent.getOrderId());
            orderApprovedEvent.setUserId(orderCreatedEvent.getUserId());
            orderApprovedEvent.setTotalPrice(orderCreatedEvent.getTotalPrice());
            LOGGER.atInfo().log(String.format("%s -> created order approved event", getClass().getSimpleName()));

            Message<OrderApprovedEvent> message = MessageBuilder
                    .withPayload(orderApprovedEvent)
                    .setHeader(KafkaHeaders.TOPIC, orderApprovedTopic)
                    .build();
            LOGGER.atInfo().log(String.format("%s -> created message", getClass().getSimpleName()));

            kafkaTemplate.send(message);
            LOGGER.atInfo().log(String.format("%s -> order approved event was sent to kafka topic", getClass().getSimpleName()));

        } else {
            LOGGER.atInfo().log(String.format("%s -> balance < total price", getClass().getSimpleName()));

            OrderRejectedEvent orderRejectedEvent = new OrderRejectedEvent();
            orderRejectedEvent.setOrderId(orderCreatedEvent.getOrderId());
            orderRejectedEvent.setUserId(orderCreatedEvent.getUserId());
            orderRejectedEvent.setReason("Insufficient balance");
            LOGGER.atInfo().log(String.format("%s -> created order rejected event", getClass().getSimpleName()));

            Message<OrderRejectedEvent> message = MessageBuilder
                    .withPayload(orderRejectedEvent)
                    .setHeader(KafkaHeaders.TOPIC, orderRejectedTopic)
                    .build();
            LOGGER.info("Created message");
            LOGGER.atInfo().log(String.format("%s -> created message", getClass().getSimpleName()));

            kafkaTemplate.send(message);
            LOGGER.atInfo().log(String.format("%s -> order rejected event was sent to kafka topic", getClass().getSimpleName()));
        }

    }

    @KafkaListener(topics = "${spring.kafka.user_rollback.name}", groupId = "${spring.kafka.consumer.group-id}")
    public void consumeFailedApproveOrderEvent(FailedApproveOrderEvent failedApproveOrderEvent) {
        LOGGER.atInfo().log(String.format("%s -> received failed approve order event", getClass().getSimpleName()));

        User user = userRepository.findById(failedApproveOrderEvent.getUserId()).orElseThrow(
                () -> new ResourceNotFoundException("User", "id", failedApproveOrderEvent.getUserId())
        );

        user.setBalance(user.getBalance() + failedApproveOrderEvent.getTotalPrice());
        user.setTotalOrders(user.getTotalOrders() - 1);
        userRepository.save(user);
        LOGGER.atInfo().log(String.format("%s -> User updated", getClass().getSimpleName()));
    }

    @KafkaListener(topics = "${spring.kafka.order_approved_dlt.name}", groupId = "${spring.kafka.consumer.group-id}")
    public void consumeOrderCreatedDlt(OrderApprovedEvent orderApprovedEvent) {
        LOGGER.atInfo().log(String.format("%s -> received order approved dlt event", getClass().getSimpleName()));

        User user = userRepository.findById(orderApprovedEvent.getUserId()).orElseThrow(
                () -> new ResourceNotFoundException("User", "id", orderApprovedEvent.getUserId())
        );

        user.setBalance(user.getBalance() + orderApprovedEvent.getTotalPrice());
        user.setTotalOrders(user.getTotalOrders() - 1);

        userRepository.save(user);
        LOGGER.atInfo().log(String.format("%s -> User updated", getClass().getSimpleName()));
    }

}
