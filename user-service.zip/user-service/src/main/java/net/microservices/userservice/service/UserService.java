package net.microservices.userservice.service;

import net.microservices.userservice.dto.UserRequest;
import net.microservices.userservice.dto.UserResponse;

public interface UserService {
    UserResponse createUser(UserRequest userRequest);
    UserResponse getUserById(Long id);
}
