package net.microservices.userservice.dto;

import lombok.Data;

@Data
public class UserResponse {
    private String name;
    private String email;
    private Double balance;
    private int totalOrders;
}
