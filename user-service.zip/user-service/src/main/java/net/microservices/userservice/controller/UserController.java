package net.microservices.userservice.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import net.microservices.userservice.service.UserService;
import net.microservices.userservice.dto.UserRequest;
import net.microservices.userservice.dto.UserResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Tag(
        name = "User Service - UserController",
        description = "User Controller Exposes REST APIs for User-Service"
)
@RestController
@RequestMapping("api/users")
public class UserController {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserController.class);

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @Operation(
            summary = "Save User REST API",
            description = "Save User REST API is used to save user object in a database"
    )
    @ApiResponse(
            responseCode = "201",
            description = "HTTP Status 201 CREATED"
    )
    @PostMapping
    public ResponseEntity<UserResponse> saveUser(@RequestBody UserRequest userRequest) {
        LOGGER.atInfo().log(String.format("%s -> received user request", getClass().getSimpleName()));

        UserResponse createdUser = userService.createUser(userRequest);
        LOGGER.atInfo().log(String.format("%s -> received response from service", getClass().getSimpleName()));

        LOGGER.atInfo().log(String.format("%s -> send response to the client", getClass().getSimpleName()));
        return new ResponseEntity<>(createdUser, HttpStatus.CREATED);
    }

    @Operation(
            summary = "Get User REST API",
            description = "Get User REST API is used to get user object from the database"
    )
    @ApiResponse(
            responseCode = "200",
            description = "HTTP Status 200 OK"
    )
    @GetMapping("{id}")
    public ResponseEntity<UserResponse> getUserById(@PathVariable("id") Long userId) {
        LOGGER.info("User controller -> received user id");

        UserResponse userResponse = userService.getUserById(userId);
        LOGGER.info("User controller -> received user from service");

        LOGGER.info("User controller -> send user to the client");
        return ResponseEntity.ok(userResponse);
    }

}
