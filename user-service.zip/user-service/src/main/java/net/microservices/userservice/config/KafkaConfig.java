package net.microservices.userservice.config;

import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.TopicBuilder;

@Configuration
public class KafkaConfig {

    @Value("${spring.kafka.order_approved.name}")
    private String orderApproved;

    @Value("${spring.kafka.order_rejected.name}")
    private String orderRejected;

    @Bean
    public NewTopic orderApprovedTopic() {
        return TopicBuilder.name(orderApproved).build();
    }

    @Bean
    public NewTopic orderRejectedTopic() {
        return TopicBuilder.name(orderRejected).build();
    }

}
