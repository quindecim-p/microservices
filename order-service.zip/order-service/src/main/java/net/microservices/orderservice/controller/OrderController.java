package net.microservices.orderservice.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import net.microservices.orderservice.dto.OrderRequest;
import net.microservices.orderservice.dto.OrderResponse;
import net.microservices.orderservice.service.OrderService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Tag(
        name = "Order Service - OrderController",
        description = "Order Controller Exposes REST APIs for Order-Service"
)
@RestController
@RequestMapping("api/orders")
public class OrderController {

    private static final Logger LOGGER = LoggerFactory.getLogger(OrderController.class);

    private final OrderService orderService;

    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    @Operation(
            summary = "Save Order REST API",
            description = "Save Order REST API is used to save order object in a database"
    )
    @ApiResponse(
            responseCode = "201",
            description = "HTTP Status 201 CREATED"
    )
    @PostMapping
    public ResponseEntity<OrderResponse> createOrder(@RequestBody OrderRequest order, @RequestParam("id") Long userId) {
        LOGGER.atInfo().log(String.format("%s -> received order request", getClass().getSimpleName()));

        order.setUserId(userId);

        OrderResponse createdOrder = orderService.saveOrder(order);
        LOGGER.atInfo().log(String.format("%s -> received response from service", getClass().getSimpleName()));

        LOGGER.atInfo().log(String.format("%s -> send response to the client", getClass().getSimpleName()));
        return new ResponseEntity<>(createdOrder, HttpStatus.CREATED);
    }

    @Operation(
            summary = "Get Order REST API",
            description = "Get Order REST API is used to get order object from the database"
    )
    @ApiResponse(
            responseCode = "200",
            description = "HTTP Status 200 OK"
    )
    @GetMapping("{id}")
    public ResponseEntity<OrderResponse> getOrderById(@PathVariable("id") Long orderId) {
        LOGGER.atInfo().log(String.format("%s -> received order id", getClass().getSimpleName()));

        OrderResponse orderResponse = orderService.getOrderById(orderId);
        LOGGER.atInfo().log(String.format("%s -> received order from service", getClass().getSimpleName()));

        LOGGER.atInfo().log(String.format("%s -> send order to the client", getClass().getSimpleName()));
        return ResponseEntity.ok(orderResponse);
    }

}
