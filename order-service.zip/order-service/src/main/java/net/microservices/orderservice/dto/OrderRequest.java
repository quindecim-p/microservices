package net.microservices.orderservice.dto;

import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

@Data
public class OrderRequest {
    @NotEmpty(message = "Order name should not be null or empty")
    private String name;
    @NotEmpty(message = "Order price should not be null or empty")
    private double price;
    @NotEmpty(message = "Order amount should not be null or empty")
    private int amount;
    private Long userId;
}
