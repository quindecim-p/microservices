package net.microservices.orderservice.dto;

import lombok.Data;

@Data
public class OrderResponse {
    private Long id;
    private String name;
    private double price;
    private int amount;
}
