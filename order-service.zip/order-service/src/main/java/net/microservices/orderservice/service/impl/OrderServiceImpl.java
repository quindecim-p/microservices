package net.microservices.orderservice.service.impl;

import net.microservices.basedomains.event.FailedApproveOrderEvent;
import net.microservices.basedomains.event.OrderApprovedEvent;
import net.microservices.basedomains.event.OrderCreatedEvent;
import net.microservices.basedomains.event.OrderRejectedEvent;
import net.microservices.orderservice.dto.OrderRequest;
import net.microservices.orderservice.dto.OrderResponse;
import net.microservices.orderservice.entity.Order;
import net.microservices.orderservice.enums.OrderStatus;
import net.microservices.orderservice.repository.OrderRepository;
import net.microservices.orderservice.service.OrderService;
import net.microservices.orderservice.exception.ResourceNotFoundException;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.RetryableTopic;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.retrytopic.TopicSuffixingStrategy;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.retry.annotation.Backoff;
import org.springframework.stereotype.Service;

@Service
public class OrderServiceImpl implements OrderService {

    @Value("${spring.kafka.order_created.name}")
    private String orderCreatedTopic;

    @Value("${spring.kafka.user_rollback.name}")
    private String userRollbackTopic;

    private static final Logger LOGGER = LoggerFactory.getLogger(OrderServiceImpl.class);

    private final OrderRepository orderRepository;

    private final ModelMapper modelMapper;

    private final KafkaTemplate<String, Object> kafkaTemplate;

    public OrderServiceImpl(OrderRepository orderRepository, ModelMapper modelMapper, KafkaTemplate<String, Object> kafkaTemplate) {
        this.orderRepository = orderRepository;
        this.kafkaTemplate = kafkaTemplate;
        this.modelMapper = modelMapper;
    }

    private double calculate(double price, int amount) {
        return price * amount;
    }

    @Override
    public OrderResponse saveOrder(OrderRequest orderRequest) {
        LOGGER.atInfo().log(String.format("%s -> received order request", getClass().getSimpleName()));

        Order order = modelMapper.map(orderRequest, Order.class);
        order.setOrderStatus(OrderStatus.CREATED);
        LOGGER.atInfo().log(String.format("%s -> Order created", getClass().getSimpleName()));

        Order savedOrder = orderRepository.save(order);
        LOGGER.atInfo().log(String.format("%s -> Order was saved in the database", getClass().getSimpleName()));

        OrderCreatedEvent orderCreatedEvent = new OrderCreatedEvent();
        orderCreatedEvent.setOrderId(savedOrder.getId());
        orderCreatedEvent.setUserId(savedOrder.getUserId());
        orderCreatedEvent.setTotalPrice(calculate(savedOrder.getPrice(), savedOrder.getAmount()));
        LOGGER.atInfo().log(String.format("%s -> Created order event", getClass().getSimpleName()));

        Message<OrderCreatedEvent> message = MessageBuilder
                .withPayload(orderCreatedEvent)
                .setHeader(KafkaHeaders.TOPIC, orderCreatedTopic)
                .build();
        LOGGER.atInfo().log(String.format("%s -> Created message", getClass().getSimpleName()));

        kafkaTemplate.send(message);
        LOGGER.atInfo().log(String.format("%s -> Created order event was sent to kafka topic", getClass().getSimpleName()));

        OrderResponse orderResponse = modelMapper.map(savedOrder, OrderResponse.class);
        LOGGER.atInfo().log(String.format("%s -> send response to the controller", getClass().getSimpleName()));

        return orderResponse;
    }

    @Override
    public OrderResponse getOrderById(Long orderId) {
        LOGGER.atInfo().log(String.format("%s -> received order id", getClass().getSimpleName()));

        Order order = orderRepository.findById(orderId).orElseThrow(
                () -> new ResourceNotFoundException("Order", "id", orderId)
        );

        OrderResponse orderResponse = modelMapper.map(order, OrderResponse.class);
        LOGGER.atInfo().log(String.format("%s -> send order to the controller", getClass().getSimpleName()));

        return orderResponse;
    }

    @KafkaListener(topics = "${spring.kafka.order_approved.name}", groupId = "${spring.kafka.consumer.group-id}")
    @RetryableTopic(
            attempts = "3",
            backoff = @Backoff(delay = 1000, multiplier = 2.0),
            autoCreateTopics = "true",
            topicSuffixingStrategy = TopicSuffixingStrategy.SUFFIX_WITH_INDEX_VALUE,
            dltTopicSuffix = "-dlt",
            include = {ResourceNotFoundException.class, Exception.class}
    )
    public void consumeOrderApprovedEvent(OrderApprovedEvent orderApprovedEvent) {
        try {
            LOGGER.atInfo().log(String.format("%s -> received order approved event", getClass().getSimpleName()));

            // Test rollback
//            if (orderApprovedEvent.getUserId() == 2) {
//                LOGGER.atError().log(String.format("%s -> Failed to approve order: %s", getClass().getSimpleName(), "Test reason"));
//
//                FailedApproveOrderEvent failedApproveOrderEvent = new FailedApproveOrderEvent();
//                failedApproveOrderEvent.setOrderId(orderApprovedEvent.getOrderId());
//                failedApproveOrderEvent.setUserId(orderApprovedEvent.getUserId());
//                failedApproveOrderEvent.setTotalPrice(orderApprovedEvent.getTotalPrice());
//                failedApproveOrderEvent.setReason("Test reason");
//                LOGGER.atInfo().log(String.format("%s -> Created failed approve order event", getClass().getSimpleName()));
//
//                Message<FailedApproveOrderEvent> message = MessageBuilder
//                        .withPayload(failedApproveOrderEvent)
//                        .setHeader(KafkaHeaders.TOPIC, userRollbackTopic)
//                        .build();
//                LOGGER.atInfo().log(String.format("%s -> Created message", getClass().getSimpleName()));
//
//                kafkaTemplate.send(message);
//                LOGGER.atInfo().log(String.format("%s -> Created failed approve order event was sent to kafka topic", getClass().getSimpleName()));
//            }

            Order order = orderRepository.findById(orderApprovedEvent.getOrderId()).orElseThrow(
                    () -> new ResourceNotFoundException("Order", "id", orderApprovedEvent.getOrderId())
            );

            order.setOrderStatus(OrderStatus.APPROVED);
            LOGGER.atInfo().log(String.format("%s -> Order status was changed to APPROVED", getClass().getSimpleName()));

            orderRepository.save(order);
            LOGGER.atInfo().log(String.format("%s -> Order was updated in the database", getClass().getSimpleName()));
        }
        catch (Exception e) {
            LOGGER.atError().log(String.format("%s -> Failed to approve order: %s", getClass().getSimpleName(), e.getMessage()));

            FailedApproveOrderEvent failedApproveOrderEvent = new FailedApproveOrderEvent();
            failedApproveOrderEvent.setOrderId(orderApprovedEvent.getOrderId());
            failedApproveOrderEvent.setUserId(orderApprovedEvent.getUserId());
            failedApproveOrderEvent.setTotalPrice(orderApprovedEvent.getTotalPrice());
            failedApproveOrderEvent.setReason(e.getMessage());
            LOGGER.atInfo().log(String.format("%s -> Created failed approve order event", getClass().getSimpleName()));

            Message<FailedApproveOrderEvent> message = MessageBuilder
                    .withPayload(failedApproveOrderEvent)
                    .setHeader(KafkaHeaders.TOPIC, userRollbackTopic)
                    .build();
            LOGGER.atInfo().log(String.format("%s -> Created message", getClass().getSimpleName()));

            kafkaTemplate.send(message);
            LOGGER.atInfo().log(String.format("%s -> Created failed approve order event was sent to kafka topic", getClass().getSimpleName()));

            throw e;
        }

    }

    @KafkaListener(topics = "${spring.kafka.order_rejected.name}", groupId = "${spring.kafka.consumer.group-id}")
    @RetryableTopic(
            attempts = "3",
            backoff = @Backoff(delay = 1000, multiplier = 2.0),
            autoCreateTopics = "true",
            topicSuffixingStrategy = TopicSuffixingStrategy.SUFFIX_WITH_INDEX_VALUE,
            dltTopicSuffix = "-dlt",
            include = {ResourceNotFoundException.class, Exception.class}
    )
    public void consumeOrderRejectedEvent(OrderRejectedEvent orderRejectedEvent) {
        LOGGER.atInfo().log(String.format("%s -> received order rejected event", getClass().getSimpleName()));

        Order order = orderRepository.findById(orderRejectedEvent.getOrderId()).orElseThrow(
                () -> new ResourceNotFoundException("Order", "id", orderRejectedEvent.getOrderId())
        );

        order.setOrderStatus(OrderStatus.REJECTED);
        LOGGER.atInfo().log(String.format("%s -> Order status was changed to REJECTED", getClass().getSimpleName()));

        orderRepository.save(order);
        LOGGER.atInfo().log(String.format("%s -> Order was updated in the database", getClass().getSimpleName()));
    }

    @KafkaListener(topics = "${spring.kafka.order_created_dlt.name}", groupId = "${spring.kafka.consumer.group-id}")
    public void consumeOrderCreatedDlt(OrderCreatedEvent orderCreatedEvent) {
        LOGGER.atInfo().log(String.format("%s -> received order created dlt event", getClass().getSimpleName()));

        Order order = orderRepository.findById(orderCreatedEvent.getOrderId()).orElseThrow(
                () -> new ResourceNotFoundException("Order", "id", orderCreatedEvent.getOrderId())
        );

        orderRepository.deleteById(order.getId());
        LOGGER.atInfo().log(String.format("%s -> Order was deleted", getClass().getSimpleName()));
    }


}
