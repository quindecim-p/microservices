package net.microservices.orderservice.config;

import net.microservices.orderservice.dto.OrderRequest;
import net.microservices.orderservice.entity.Order;
import org.modelmapper.ModelMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ModelMapperConfig {

    @Bean
    public ModelMapper modelMapper() {
        ModelMapper mapper = new ModelMapper();
        mapper.getConfiguration().setSkipNullEnabled(true);
        mapper.createTypeMap(OrderRequest.class, Order.class)
                .addMappings(m -> m.skip(Order::setId));
        return mapper;
    }

}