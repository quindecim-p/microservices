package net.microservices.orderservice.service;

import net.microservices.orderservice.dto.OrderRequest;
import net.microservices.orderservice.dto.OrderResponse;

public interface OrderService {
    OrderResponse saveOrder(OrderRequest orderRequest);
    OrderResponse getOrderById(Long orderId);
}
