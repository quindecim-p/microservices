package net.microservices.orderservice.enums;

public enum OrderStatus {
    CREATED,
    APPROVED,
    REJECTED
}