CREATE TABLE orders (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    amount INTEGER NOT NULL,
    order_status VARCHAR(50) NOT NULL,
    user_id BIGINT NOT NULL REFERENCES users(id)
);

COMMENT ON TABLE users IS 'Table for orders data';